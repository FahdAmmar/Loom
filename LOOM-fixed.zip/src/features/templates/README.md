# templates

**Implemented (Phase 6):**

- `api/templates.ts` — save a page's blocks as a reusable `Template`, then
  stamp out new pages from it
- `TemplatesRoute` — gallery (name + block count), "Use template" creates a
  page and navigates straight to it, delete removes a template
- "Save as template" lives in the shared `PageActionsMenu` (`features/pages/`)
- Eight ready-made templates ship in the seed data out of the box: Meeting
  notes, Project brief, Weekly planner, Reading notes, Design critique,
  Todo board, Bug tracker, Daily journal — covering headings, tables,
  checklists, numbered lists, quotes, callouts, and (the last two of the
  eight) the board block type

**Implemented (later addition): board-based templates.** Todo board and Bug
tracker both include a `board` block — unlike a toggle, a board's
"children" (columns, cards) all live nested inside that one block's own
`content`, not as separate child blocks, so it fits the existing flat
`Template.blocks` shape with no changes needed (see the known limitation
below, which is specifically about _block_ nesting, not content nesting
within a single block).

**Implemented (later addition): visual gallery, replacing the plain
name-and-icon list.** `TemplatePreview` (new,
`features/templates/components/`) renders a genuine miniature of a
template's actual content — real text, real table cells, real board column
colors and card titles — not a static image saved anywhere, and (after an
initial version) not an abstract wireframe of bars and lines either. It
reuses the real block components' own styling (`TextBlockView`'s heading
weights, `BoardBlockView`'s column colors) and renders the actual saved
HTML at normal size inside a fixed-width (`380px`) off-screen frame, then
scales that whole frame down with CSS `transform: scale()` — the same
technique real template pickers (PowerPoint, Canva, Notion) use, rather
than drawing a simplified stand-in. The scale factor is measured live via
`ResizeObserver` against the card's actual rendered width rather than
hardcoded, since the gallery grid's column count (and so each card's width)
changes at every breakpoint; a fixed scale would leave gaps at some widths
and overflow at others. Because it's the real content, not a rendering of
it, this can never drift out of sync with what "Use template" actually
produces, and a template saved later from a real page (`PageActionsMenu`'s
"Save as template") gets a correct preview for free with no image to
generate or store. The preview is marked `aria-hidden` — the card
button's own visible template name already gives it a correct accessible
name, and a screen reader stepping through a mini table/board/checklist a
second time inside the same button would be noise, not information.

`TemplatesRoute` is now a responsive grid of cards instead of a vertical
list. The whole card is a button (click anywhere to use the template, not
just a "Use template" label); hovering reveals that label as an overlay on
the preview plus a delete icon in the corner. The delete button is a
sibling positioned over the card, not a descendant of it — nesting a
`<button>` inside another `<button>` is invalid HTML, and this was the
simplest way around that without giving up a fully-clickable card.

**Fixed:** `handleUse` created the page through `templatesApi` directly,
bypassing `usePageStore` — the new page was persisted but the store's
`pagesById` cache never learned about it, so the router's page lookup (and
the sidebar tree) couldn't see it and showed "This page doesn't exist."
Fixed by adding a small `addPage` action to `usePageStore` and calling it
right after creation.

**Fixed: nested blocks now survive being saved into a template.**
`Template.blocks` used to be flat (`Pick<Block, "type" | "content" |
"order">[]`), so a toggle's children never made it into a saved template —
previously documented here as a known limitation. `TemplateBlock` now adds
a `children: TemplateBlock[]` to that same shape, and `createTemplateFromPage`
/ `createPageFromTemplate` in `api/templates.ts` walk that tree recursively
(via each block's `parentBlockId`) instead of only reading top-level
blocks. `TemplatePreview` is intentionally left reading `template.blocks`
flat, top-level only — it's a small decorative miniature, not a full
render, and the templates that actually use toggles look the same in the
gallery either way; the real nested content is there once "Use template"
actually creates the page.
